create trigger TOS
  before insert or update
  on STUDD
  for each row
declare
tos stuname.studd%type;
begin
select stuname into tos from studd where sid=10;
if(:new.stuname=tos) then
raise_application_error(-56999,'this is error');
end if;
end;
/

