create trigger TY
  before insert
  on STU1
  for each row
declare
name varchar(8);
begin
select user into name from dual;
:new.un:=name;
end;
/

